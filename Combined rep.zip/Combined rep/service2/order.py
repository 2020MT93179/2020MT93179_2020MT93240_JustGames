from flask import Flask, render_template, request
from flask_mysqldb import MySQL

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'flaskdb'

mysql = MySQL(app)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/welcome')
def welcome():
    return render_template('welcome.html')


@app.route('/orderForm')
def orderForm():
    return render_template('orderForm.html')


@app.route('/order', methods=['POST', 'GET'])
def order():
    if request.method == 'GET':
        return render_template('welcome.html')
    if request.method == 'POST':
        gamename = request.form['name']
        print(gamename)
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT game_id FROM games WHERE game_name='{}' AND flag=1".format(gamename))
        record = cursor.fetchall()
        if record:
            print("Game available in store")
            print(record[0][0])
            gid = int(record[0][0])
            cursor.execute("UPDATE games SET flag=0, store_id=1 WHERE game_id={}".format(gid))
            mysql.connection.commit()
            cursor.close()
            return f"Game order placed!"
        else:
            print("Unavailable")
            return f"We do not have a copy of this game available now. Please try later."

app.run(host='localhost', port=5002)
