from flask import Flask, render_template, request
from flask_mysqldb import MySQL

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'flaskdb'

mysql = MySQL(app)
defaultStore = 1

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/welcome')
def welcome():
    return render_template('welcome.html')

@app.route('/form')
def form():
    return render_template('form.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'GET':
        return render_template('welcome.html')
    if request.method == 'POST':
        gamename = request.form['name']
        print(gamename)
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT game_id FROM games WHERE game_name='{}' AND store_id={} AND flag=1".format(gamename, defaultStore))
        record = cursor.fetchall()
        if record:
            print("Game available in store")
            print(record[0][0])
            gid = int(record[0][0])
            cursor.execute("UPDATE games SET flag=0 WHERE game_id={}".format(gid))
            mysql.connection.commit()
            cursor.close()
            return f"Game checked out!"
        else:
            print("Unavailable")
            return f"This game is not available in this store. Please use the order function to check other stores."

app.run(host='localhost', port=5000)
